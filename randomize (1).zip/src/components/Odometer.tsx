import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface OdometerProps {
  value: number;
  digits?: number;
}

export const Odometer: React.FC<OdometerProps> = ({ value, digits = 2 }) => {
  const safeValue = typeof value === 'number' && !isNaN(value) ? value : 0;
  const valueString = String(safeValue).padStart(digits, '0');
  const digitsArray = valueString.split('');

  return (
    <div className="flex gap-1 justify-center select-none" id="odometer-container">
      {digitsArray.map((digit, index) => {
        const parsedDigit = parseInt(digit, 10);
        return (
          <SingleDigitColumn 
            key={index} 
            targetDigit={isNaN(parsedDigit) ? 0 : parsedDigit} 
            index={index} 
          />
        );
      })}
    </div>
  );
};

const SingleDigitColumn: React.FC<{ targetDigit: number; index: number }> = ({ targetDigit, index }) => {
  const [spinCount, setSpinCount] = useState(0);
  const [renderedDigit, setRenderedDigit] = useState(targetDigit);

  // Trigger spin on load or target digit alteration
  useEffect(() => {
    // Elevate spin count to simulate longer rolls
    setSpinCount((prev) => prev + 1);
    const timeout = setTimeout(() => {
      setRenderedDigit(targetDigit);
    }, 150 + index * 100); // Stagger the arrival of digits for maximum premium aesthetic

    return () => clearTimeout(timeout);
  }, [targetDigit, index]);

  const height = 54; // matching --digit-h in CSS
  const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

  return (
    <div 
      className="odo-digit w-[33px] h-[54px] sm:w-[38px] sm:h-[58px] overflow-hidden relative rounded-md border border-white/10 dark:border-white/10 light:border-black/5 bg-[#161616] dark:bg-[#161616] light:bg-[#EFEFF4] transition-colors"
      style={{
        boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.4)'
      }}
    >
      <motion.div
        className="flex flex-col justify-start absolute left-0 right-0"
        initial={{ y: 0 }}
        animate={{ 
          y: -((spinCount * 10 + targetDigit) % 10) * height 
        }}
        transition={{ 
          type: 'spring', 
          stiffness: 90 + index * 20, 
          damping: 14 + index * 2,
          mass: 1
        }}
      >
        {/* We repeat numbers list so it spins consecutively */}
        {numbers.map((n) => (
          <div 
            key={n} 
            className="odo-num h-[54px] sm:h-[58px] flex items-center justify-center font-mono font-bold text-xl sm:text-2xl text-[#F2F0FA] dark:text-[#F2F0FA] light:text-[#18181B]"
          >
            {n}
          </div>
        ))}
      </motion.div>
      
      {/* Top and bottom subtle overlay gradients to enhance 3D cylinder appearance */}
      <div className="absolute top-0 left-0 right-0 h-3 bg-gradient-to-b from-black/40 to-transparent pointer-events-none" />
      <div className="absolute bottom-0 left-0 right-0 h-3 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />
    </div>
  );
};
