import React, { useState } from 'react';
import { Review } from '../types';
import { auth, saveEpisodeReview } from '../lib/firebase';
import { Star, MessageSquare } from 'lucide-react';

interface EpisodeReviewFormProps {
  showName: string;
  season: number;
  number: number;
  onReviewSubmitted: () => void;
}

export const EpisodeReviewForm: React.FC<EpisodeReviewFormProps> = ({
  showName,
  season,
  number,
  onReviewSubmitted
}) => {
  const [rating, setRating] = useState<number>(8); // default to 8
  const [comment, setComment] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const currentUser = auth.currentUser;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setError('You must be signed in to submit a review.');
      return;
    }
    if (!comment.trim()) {
      setError('Please add a brief comment explaining your rating.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    setSuccess(false);

    try {
      const reviewId = `review_${currentUser.uid}_${Date.now()}`;
      const newReview: Review = {
        id: reviewId,
        userId: currentUser.uid,
        userDisplayName: currentUser.displayName || 'Anonymous Fan',
        showName,
        season,
        number,
        rating,
        comment: comment.trim(),
        createdAt: new Date().toISOString()
      };

      await saveEpisodeReview(newReview);
      setSuccess(true);
      setComment('');
      onReviewSubmitted();
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to submit review. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!currentUser) {
    return (
      <div className="p-5 border border-dashed border-white/10 rounded-xl text-center bg-transparent mt-4">
        <p className="text-gray-400 dark:text-gray-400 light:text-gray-600 text-sm mb-2">Want to rate this episode?</p>
        <p className="text-xs text-[var(--violet)] font-semibold font-mono">Sign in to leave a community rating and review!</p>
      </div>
    );
  }

  return (
    <div className="bg-white/5 border border-white/5 rounded-xl p-5 mt-6 w-full text-left">
      <h4 className="text-gray-900 dark:text-[#F2F0FA] font-semibold text-base mb-1 flex items-center gap-2">
        <Star className="w-4 h-4 text-[var(--violet)]" fill="currentColor" />
        Rate this Episode
      </h4>
      <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">Share your score with the Randomize community.</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-gray-500 dark:text-gray-400 font-mono">YOUR SCORE</span>
            <span className="text-[var(--violet)] font-bold font-mono text-sm">{rating}/10</span>
          </div>
          <div className="flex items-center gap-3">
            <input 
              type="range" 
              min="1" 
              max="10" 
              value={rating} 
              onChange={(e) => setRating(parseInt(e.target.value, 10))}
              className="flex-1 accent-[var(--violet)] h-1 bg-white/10 rounded-lg cursor-pointer" 
            />
            <div className="flex gap-1">
              {[...Array(10)].map((_, i) => (
                <button
                  type="button"
                  key={i}
                  onClick={() => setRating(i + 1)}
                  className={`w-3.5 h-3.5 rounded-full transition-colors ${i < rating ? 'bg-[var(--violet)]' : 'bg-white/10'}`}
                  title={`${i + 1}/10`}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-mono text-gray-500 dark:text-gray-400 uppercase">COMMENT</label>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={2}
            placeholder="What did you think of this episode? Highlight funny moments or cool details..."
            className="w-full bg-[var(--bg)] border border-white/10 rounded-lg p-3 text-sm text-gray-900 dark:text-[#F2F0FA] placeholder-gray-500 focus:outline-none focus:border-[var(--violet)] transition-colors resize-none"
            maxLength={1000}
          />
        </div>

        {error && (
          <p className="text-xs text-red-500 dark:text-red-400 font-mono" id="review-error-message">{error}</p>
        )}

        {success && (
          <p className="text-xs text-emerald-500 dark:text-emerald-400 font-mono" id="review-success-message">🎉 Your review has been shared with the community!</p>
        )}

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-gradient-to-r from-[var(--violet)] to-[var(--magenta)] text-white py-2 px-4 rounded-lg font-bold text-sm hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer shadow-md"
        >
          <MessageSquare className="w-4 h-4" />
          {isSubmitting ? 'Sharing...' : 'Submit Community Review'}
        </button>
      </form>
    </div>
  );
};
