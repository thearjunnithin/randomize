import React, { useState, useEffect } from 'react';
import { Sparkles, Star } from 'lucide-react';

interface PopularShowCardProps {
  key?: React.Key;
  name: string;
  count: number;
  fallbackImg?: string;
  onClick: () => void;
}

export function PopularShowCard({ name, count, fallbackImg, onClick }: PopularShowCardProps) {
  const [imgUrl, setImgUrl] = useState<string | null>(fallbackImg || null);
  const [isLoading, setIsLoading] = useState<boolean>(!fallbackImg);

  useEffect(() => {
    let isMounted = true;
    
    // Always query live details from TVMaze to ensure 100% correct matching image
    fetch(`https://api.tvmaze.com/singlesearch/shows?q=${encodeURIComponent(name)}`)
      .then(res => {
        if (res.ok) return res.json();
        throw new Error();
      })
      .then(data => {
        if (isMounted && data && data.image) {
          const fetched = data.image.medium || data.image.original;
          if (fetched) {
            setImgUrl(fetched);
          }
        }
        if (isMounted) setIsLoading(false);
      })
      .catch(() => {
        if (isMounted) {
          setIsLoading(false);
          // Keep fallback if available, or stay null
        }
      });

    return () => {
      isMounted = false;
    };
  }, [name]);

  return (
    <button
      onClick={onClick}
      className="group text-left panel p-2.5 space-y-2 border-white/5 bg-white/5 hover:bg-[#161616] hover:border-[var(--violet)]/30 hover:-translate-y-1 transition-all cursor-pointer shadow-none flex flex-col justify-between h-full"
    >
      <div className="relative aspect-[3/4.2] overflow-hidden rounded-lg bg-gray-950 border border-white/5 w-full flex-1 flex items-center justify-center">
        {isLoading ? (
          <div className="flex flex-col items-center gap-1.5 text-gray-500 font-mono text-[10px]">
            <span className="w-2 h-2 rounded-full bg-[var(--violet)] animate-ping" />
            <span>Loading...</span>
          </div>
        ) : imgUrl ? (
          <img 
            src={imgUrl} 
            alt={name} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="flex flex-col items-center justify-center text-center p-3 text-gray-600">
            <Sparkles className="w-5 h-5 mb-1 text-gray-600" />
            <span className="text-[10px] font-mono leading-none">Aesthetic Grid</span>
          </div>
        )}
      </div>

      <div className="px-1 text-left pt-1 shrink-0 w-full">
        <h4 className="text-[#F2F0FA] group-hover:text-[var(--violet)] dark:text-[#F2F0FA] light:text-gray-950 font-bold text-xs truncate max-w-full transition-colors">
          {name}
        </h4>
        <span className="text-[10px] text-gray-400 font-mono">
          {count} Episodes
        </span>
      </div>
    </button>
  );
}
