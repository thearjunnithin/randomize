import React, { useState } from 'react';
import { auth, saveUserProfile } from '../lib/firebase';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile 
} from 'firebase/auth';
import { motion } from 'motion/react';
import { X, Mail, Lock, User, Sparkles } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (isSignUp) {
        if (!displayName.trim()) {
          throw new Error('Please enter a display name.');
        }
        // Sign Up
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Update user profile in Auth
        await updateProfile(user, {
          displayName: displayName.trim()
        });

        // Save progress profile in Firestore
        await saveUserProfile(user.uid, displayName.trim(), email);
      } else {
        // Sign In
        await signInWithEmailAndPassword(auth, email, password);
      }
      
      // Close on success
      onClose();
      // Reset form
      setEmail('');
      setPassword('');
      setDisplayName('');
    } catch (err: any) {
      console.error(err);
      let friendlyError = err.message;
      if (err.code === 'auth/invalid-credential') {
        friendlyError = 'Invalid email or password. Please verify and try again.';
      } else if (err.code === 'auth/email-already-in-use') {
        friendlyError = 'This email is already registered. Please sign in instead.';
      } else if (err.code === 'auth/weak-password') {
        friendlyError = 'Password should be at least 6 characters.';
      } else if (err.code === 'auth/invalid-email') {
        friendlyError = 'Please enter a valid email address.';
      }
      setError(friendlyError);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-[#05040C]/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      {/* Click outside to close */}
      <div className="absolute inset-0" onClick={onClose} />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92, y: 15 }}
        transition={{ type: 'spring', duration: 0.3 }}
        className="relative w-full max-w-[390px] bg-[#15132B] border border-[rgba(255,255,255,0.1)] rounded-2xl p-7 shadow-2xl z-10"
      >
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4.5 right-4.5 w-8 h-8 rounded-full bg-[#1C1939] text-[#9690B8] hover:text-[#F2F0FA] hover:bg-[#1C1939]/80 flex items-center justify-center transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#7C5CFC] to-[#C66DF2] flex items-center justify-center mx-auto mb-3 shadow-[#7C5CFC]/30 shadow-md">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-[#F2F0FA] font-display font-extrabold text-xl mb-1">
            {isSignUp ? 'Create your account' : 'Welcome back'}
          </h3>
          <p className="text-xs text-gray-400">
            {isSignUp ? 'Keep your favorite episodes synced across devices.' : 'Sign in to access your saved favorites & leave ratings.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <div className="space-y-1.5 text-left">
              <label className="text-[10px] font-mono text-[#9690B8] font-bold tracking-wider">DISPLAY NAME</label>
              <div className="relative">
                <User className="absolute left-3.5 top-3 w-4 h-4 text-gray-500" />
                <input
                  type="text"
                  placeholder="TV Fanatic"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full bg-[#1C1939] border border-white/5 rounded-xl pl-11 pr-4 py-2.5 text-sm text-[#F2F0FA] focus:outline-none focus:border-[#7C5CFC] transition-colors"
                  required={isSignUp}
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5 text-left">
            <label className="text-[10px] font-mono text-[#9690B8] font-bold tracking-wider">EMAIL ADDRESS</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3 w-4 h-4 text-gray-500" />
              <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#1C1939] border border-white/5 rounded-xl pl-11 pr-4 py-2.5 text-sm text-[#F2F0FA] focus:outline-none focus:border-[#7C5CFC] transition-colors"
                required
              />
            </div>
          </div>

          <div className="space-y-1.5 text-left">
            <label className="text-[10px] font-mono text-[#9690B8] font-bold tracking-wider">PASSWORD</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3 w-4 h-4 text-gray-500" />
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#1C1939] border border-white/5 rounded-xl pl-11 pr-4 py-2.5 text-sm text-[#F2F0FA] focus:outline-none focus:border-[#7C5CFC] transition-colors"
                required
              />
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-400 font-mono text-center bg-red-400/5 py-1.5 px-3 rounded-lg border border-red-500/10">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-[#7C5CFC] to-[#C66DF2] text-white py-2.5 rounded-xl font-bold text-sm tracking-wide hover:brightness-105 active:scale-[0.98] transition-all cursor-pointer shadow-lg shadow-[#7C5CFC]/25 disabled:opacity-50"
          >
            {isLoading ? 'Processing...' : isSignUp ? 'Sign Up' : 'Sign In'}
          </button>
        </form>

        <p className="text-center text-xs text-gray-400 mt-6 pt-4 border-t border-white/5">
          {isSignUp ? 'Already have an account?' : "Don't have an account?"}{' '}
          <button
            onClick={() => {
              setIsSignUp(!isSignUp);
              setError(null);
            }}
            className="text-[#7C5CFC] font-semibold hover:underline bg-transparent border-0 cursor-pointer"
          >
            {isSignUp ? 'Sign in' : 'Sign up'}
          </button>
        </p>
      </motion.div>
    </div>
  );
};
