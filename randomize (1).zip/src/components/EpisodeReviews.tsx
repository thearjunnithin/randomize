import React, { useEffect, useState } from 'react';
import { Review } from '../types';
import { fetchEpisodeReviews, fetchEpisodeSummaryRating } from '../lib/firebase';
import { Star, MessageSquareCode, Calendar, User, Users } from 'lucide-react';

interface EpisodeReviewsProps {
  showName: string;
  season: number;
  number: number;
  refreshKey: number; // key to force polling update on review submission
}

export const EpisodeReviews: React.FC<EpisodeReviewsProps> = ({
  showName,
  season,
  number,
  refreshKey
}) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [average, setAverage] = useState<number | null>(null);
  const [count, setCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let active = true;

    async function loadData() {
      setIsLoading(true);
      try {
        const [reviewsList, summary] = await Promise.all([
          fetchEpisodeReviews(showName, season, number),
          fetchEpisodeSummaryRating(showName, season, number)
        ]);

        if (active) {
          setReviews(reviewsList);
          setAverage(summary.averageRating);
          setCount(summary.ratingCount);
        }
      } catch (err) {
        console.error('Error loading reviews:', err);
      } finally {
        if (active) {
          setIsLoading(false);
        }
      }
    }

    loadData();

    return () => {
      active = false;
    };
  }, [showName, season, number, refreshKey]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-6 gap-2 text-xs font-mono text-gray-500">
        <span className="w-1.5 h-1.5 rounded-full bg-[var(--violet)] animate-ping" />
        Loading community ratings...
      </div>
    );
  }

  return (
    <div className="mt-8 border-t border-white/5 pt-6 w-full text-left">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h3 className="text-gray-900 dark:text-[#F2F0FA] font-bold text-lg flex items-center gap-2">
            <Users className="w-5 h-5 text-[var(--violet)]" />
            Community Reviews
          </h3>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Fan scores and written breakdowns for this episode.</p>
        </div>

        {/* Global score stats */}
        {count > 0 ? (
          <div className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 flex items-center gap-3">
            <div className="text-right">
              <div className="text-xs text-gray-500 dark:text-gray-400 font-mono">AVG RATING</div>
              <div className="text-xs text-gray-500 font-mono">{count} review{count === 1 ? '' : 's'}</div>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-2xl font-black text-[var(--violet)] font-mono leading-none">
                {average}
              </span>
              <span className="text-gray-900 dark:text-[#F2F0FA] font-mono text-xs opacity-60">/10</span>
            </div>
          </div>
        ) : (
          <div className="text-xs text-gray-500 italic">No community reviews yet. Be the first to leave one!</div>
        )}
      </div>

      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1 scrollbar-thin">
        {reviews.length > 0 ? (
          reviews.map((rev) => (
            <div 
              key={rev.id} 
              className="bg-white/5 border border-white/5 rounded-xl p-4 space-y-2 transition-all hover:border-white/10"
            >
              <div className="flex justify-between items-start gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[var(--violet)]/20 to-[var(--magenta)]/20 border border-white/10 flex items-center justify-center text-[var(--violet)]">
                    <User className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-gray-950 dark:text-[#F2F0FA] block">{rev.userDisplayName}</span>
                    <span className="text-[10px] text-gray-500 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(rev.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                  </div>
                </div>

                <div className="bg-black/30 border border-white/5 rounded px-2 py-0.5 flex items-center gap-1">
                  <Star className="w-3 h-3 text-[var(--violet)]" fill="currentColor" />
                  <span className="text-xs font-bold text-[var(--violet)] font-mono">{rev.rating}</span>
                  <span className="text-[9px] text-gray-500 font-mono">/10</span>
                </div>
              </div>

              <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed pl-1">
                {rev.comment}
              </p>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-xs text-gray-500 flex flex-col items-center gap-2">
            <MessageSquareCode className="w-10 h-10 text-gray-400 dark:text-gray-700 stroke-1" />
            No comments yet. Share your thoughts using the review box above!
          </div>
        )}
      </div>
    </div>
  );
};
