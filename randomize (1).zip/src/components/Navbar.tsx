import React, { useState, useEffect } from 'react';
import { useTheme } from './ThemeContext';
import { auth } from '../lib/firebase';
import { onAuthStateChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import { Tv, Sun, Moon, Menu, X, User, LogOut, Heart, HelpCircle, Info, Sparkles } from 'lucide-react';

interface NavbarProps {
  activePage: string;
  setActivePage: (page: string) => void;
  onOpenAuthModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  setActivePage,
  onOpenAuthModal
}) => {
  const { theme, toggleTheme } = useTheme();
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setIsMobileMenuOpen(false);
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  const menuItems = [
    { id: 'home', label: 'Home', icon: Tv },
    { id: 'custom', label: 'Custom Profiles', icon: Sparkles },
    { id: 'about', label: 'About', icon: Info },
    { id: 'how', label: 'How it Works', icon: HelpCircle },
    { id: 'favorites', label: 'Favorites', icon: Heart }
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#050505]/80 dark:bg-[#050505]/80 light:bg-white/80 backdrop-blur-md border-b border-white/5 transition-colors duration-200">
      <div className="max-w-[1180px] mx-auto px-6 py-4 flex items-center justify-between gap-4">
        {/* Brand */}
        <button 
          onClick={() => setActivePage('home')}
          className="flex items-center gap-2.5 font-sans font-extrabold text-xl tracking-tight text-[#F2F0FA] group text-left cursor-pointer"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--violet)] to-[var(--magenta)] flex items-center justify-center shadow-lg shadow-[var(--violet)]/20 group-hover:scale-105 transition-transform">
            <Tv className="w-4.5 h-4.5 text-white" fill="none" />
          </div>
          <span className="bg-gradient-to-r from-white to-[#F2F0FA] bg-clip-text text-transparent dark:from-white dark:to-[#F2F0FA] light:from-gray-900 light:to-gray-800">
            Randomize
          </span>
        </button>

        {/* Regular links (desktop only) */}
        <nav className="hidden md:flex items-center gap-7">
          {menuItems.map((item) => {
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActivePage(item.id)}
                className={`relative py-1.5 text-sm font-medium transition-colors cursor-pointer ${
                  isActive 
                    ? 'text-gray-900 dark:text-[#F2F0FA]' 
                    : 'text-gray-400 hover:text-gray-900 dark:hover:text-[#F2F0FA]'
                }`}
              >
                {item.label}
                {isActive && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r from-[var(--violet)] to-[var(--magenta)] rounded-full"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center gap-3">
          {/* Theme switcher */}
          <button
            onClick={toggleTheme}
            className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-gray-400 hover:text-[#F2F0FA] hover:border-[var(--violet)] transition-all cursor-pointer bg-white/5 active:scale-95"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-300" />
            ) : (
              <Moon className="w-4 h-4 text-indigo-500" />
            )}
          </button>

          {/* User Auth display / SignIn button */}
          {user ? (
            <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl py-1 pl-3 pr-1.5">
              <span className="text-xs font-semibold text-gray-300 dark:text-gray-300 light:text-gray-700">
                Hi, {user.displayName || user.email?.split('@')[0]}
              </span>
              <button
                onClick={handleSignOut}
                className="w-7 h-7 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 flex items-center justify-center transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="px-4 py-2 border border-[var(--violet)] text-[var(--violet)] bg-transparent text-sm font-bold rounded-xl hover:bg-[var(--violet)]/10 active:scale-[0.98] transition-all cursor-pointer"
            >
              Sign In
            </button>
          )}
        </div>

        {/* Hamburger / controls button (mobile only) */}
        <div className="flex md:hidden items-center gap-2">
          {/* Theme toggler */}
          <button
            onClick={toggleTheme}
            className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-gray-400 transition-all bg-white/5 active:scale-95"
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-300" />
            ) : (
              <Moon className="w-4 h-4 text-indigo-500" />
            )}
          </button>

          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="w-9 h-9 rounded-lg border border-white/10 flex items-center justify-center text-[#F2F0FA] bg-white/5 transition-all outline-none"
            aria-expanded={isMobileMenuOpen}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-4.5 h-4.5" /> : <Menu className="w-4.5 h-4.5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.18 }}
            className="md:hidden border-t border-white/10 bg-[#050505]/95 overflow-hidden"
          >
            <div className="flex flex-col gap-3 px-6 py-4">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActivePage(item.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-3 py-2 px-3 rounded-lg text-sm font-semibold transition-all ${
                      isActive 
                        ? 'bg-gradient-to-r from-[var(--violet)]/10 to-[var(--magenta)]/10 text-white border border-[var(--violet)]/20' 
                        : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Icon className="w-4.5 h-4.5" />
                    {item.label}
                  </button>
                );
              })}

              <div className="h-[1px] bg-white/10 my-1" />

              {user ? (
                <div className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl p-3">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-violet-400" />
                    <span className="text-sm font-semibold text-gray-300">
                      {user.displayName || user.email?.split('@')[0]}
                    </span>
                  </div>
                  <button
                    onClick={handleSignOut}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-red-500/10 text-red-400 text-xs font-bold hover:bg-red-500/20"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Sign Out
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    onOpenAuthModal();
                    setIsMobileMenuOpen(false);
                  }}
                  className="w-full text-center py-2.5 border border-[var(--violet)] text-[var(--violet)] font-bold text-sm rounded-xl"
                >
                  Sign In
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
