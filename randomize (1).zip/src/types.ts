export interface TVShow {
  id: number;
  name: string;
  summary: string;
  image: string | null;
  premiered: string;
  ended: string | null;
  network: string;
  genres: string[];
  imdbId: string | null;
}

export interface Episode {
  id: number;
  season: number;
  number: number;
  name: string;
  airdate: string;
  runtime: number;
  summary: string;
  image: {
    medium: string;
    original: string;
  } | null;
  rating?: {
    average: number | null;
  };
}

export interface FirestoreUser {
  id: string;
  displayName: string;
  email: string;
}

export interface Favorite {
  id: string; // doc ID
  userId: string;
  showName: string;
  season: number;
  number: number;
  title: string;
  image: string | null;
  airdate: string;
  createdAt: string; // ISO string
}

export interface Review {
  id: string; // doc ID
  userId: string;
  userDisplayName: string;
  showName: string;
  season: number;
  number: number;
  rating: number; // 1-10
  comment: string;
  createdAt: string; // ISO string;
}

export interface CustomShow {
  id: string;
  userId: string;
  name: string;
  seasons: number;
  episodesPerSeason: number;
  summary: string;
  genre: string;
  premieredYear: string;
  createdAt: string;
}
