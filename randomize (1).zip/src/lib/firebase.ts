import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as firebaseSignOut,
  updateProfile,
  User as FirebaseUserType
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  query, 
  where, 
  orderBy, 
  getDocs, 
  deleteDoc 
} from 'firebase/firestore';
import { Favorite, Review, FirestoreUser, CustomShow } from '../types';

// Read config directly
import config from '../../firebase-applet-config.json';

const app = initializeApp(config);
export const auth = getAuth(app);
export const db = getFirestore(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Creates/saves a user profile in Firestore
 */
export async function saveUserProfile(uid: string, displayName: string, email: string) {
  const path = `users/${uid}`;
  try {
    const userDocRef = doc(db, 'users', uid);
    const userData: FirestoreUser = {
      id: uid,
      displayName,
      email
    };
    await setDoc(userDocRef, userData);
    return userData;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

/**
 * Gets a user profile from Firestore
 */
export async function getUserProfile(uid: string): Promise<FirestoreUser | null> {
  const path = `users/${uid}`;
  try {
    const userDocRef = doc(db, 'users', uid);
    const userSnap = await getDoc(userDocRef);
    if (userSnap.exists()) {
      return userSnap.data() as FirestoreUser;
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

/**
 * Saves a favorite episode for a user
 */
export async function saveFavoriteEpisode(favorite: Favorite) {
  const path = `favorites/${favorite.id}`;
  try {
    const favDocRef = doc(db, 'favorites', favorite.id);
    await setDoc(favDocRef, favorite);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

/**
 * Removes a favorite episode from Firestore
 */
export async function deleteFavoriteEpisode(favoriteId: string) {
  const path = `favorites/${favoriteId}`;
  try {
    const favDocRef = doc(db, 'favorites', favoriteId);
    await deleteDoc(favDocRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

/**
 * Gets all favorites for a specific user
 */
export async function fetchUserFavorites(userId: string): Promise<Favorite[]> {
  const path = 'favorites';
  try {
    const favoritesCol = collection(db, 'favorites');
    const q = query(
      favoritesCol, 
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const list: Favorite[] = [];
    querySnapshot.forEach((doc) => {
      list.push(doc.data() as Favorite);
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

/**
 * Submits a new community review
 */
export async function saveEpisodeReview(review: Review) {
  const path = `reviews/${review.id}`;
  try {
    const reviewDocRef = doc(db, 'reviews', review.id);
    await setDoc(reviewDocRef, review);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

/**
 * Fetches all reviews for a specific episode
 */
export async function fetchEpisodeReviews(showName: string, season: number, number: number): Promise<Review[]> {
  const path = 'reviews';
  try {
    const reviewsCol = collection(db, 'reviews');
    const q = query(
      reviewsCol,
      where('showName', '==', showName),
      where('season', '==', season),
      where('number', '==', number),
      orderBy('createdAt', 'desc')
    );

    const querySnapshot = await getDocs(q);
    const list: Review[] = [];
    querySnapshot.forEach((doc) => {
      list.push(doc.data() as Review);
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

/**
 * Fetches the average rating and review details for an episode
 */
export async function fetchEpisodeSummaryRating(showName: string, season: number, number: number) {
  const path = 'reviews';
  try {
    const reviewsCol = collection(db, 'reviews');
    const q = query(
      reviewsCol,
      where('showName', '==', showName),
      where('season', '==', season),
      where('number', '==', number)
    );
    
    const querySnapshot = await getDocs(q);
    let totalRating = 0;
    let count = 0;
    querySnapshot.forEach((doc) => {
      const data = doc.data() as Review;
      totalRating += data.rating;
      count++;
    });
    
    return {
      averageRating: count > 0 ? Number((totalRating / count).toFixed(1)) : null,
      ratingCount: count
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

/**
 * Saves a custom show profile to Firestore
 */
export async function saveCustomShow(show: CustomShow) {
  const path = `custom_shows/${show.id}`;
  try {
    const showDocRef = doc(db, 'custom_shows', show.id);
    await setDoc(showDocRef, show);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

/**
 * Removes a custom show profile from Firestore
 */
export async function deleteCustomShow(showId: string) {
  const path = `custom_shows/${showId}`;
  try {
    const showDocRef = doc(db, 'custom_shows', showId);
    await deleteDoc(showDocRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

/**
 * Fetches all custom show profiles from Firestore
 */
export async function fetchAllCustomShows(): Promise<CustomShow[]> {
  const path = 'custom_shows';
  try {
    const showsCol = collection(db, 'custom_shows');
    const q = query(showsCol, orderBy('createdAt', 'desc'));
    
    const querySnapshot = await getDocs(q);
    const list: CustomShow[] = [];
    querySnapshot.forEach((doc) => {
      list.push(doc.data() as CustomShow);
    });
    return list;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}
