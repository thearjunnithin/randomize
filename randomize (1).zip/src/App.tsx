import React, { useState, useEffect } from 'react';
import { ThemeProvider, useTheme } from './components/ThemeContext';
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { Odometer } from './components/Odometer';
import { EpisodeReviewForm } from './components/EpisodeReviewForm';
import { EpisodeReviews } from './components/EpisodeReviews';
import { TVShow, Episode, Favorite, Review, CustomShow } from './types';
import { 
  auth, 
  saveFavoriteEpisode, 
  deleteFavoriteEpisode, 
  fetchUserFavorites,
  saveCustomShow,
  deleteCustomShow,
  fetchAllCustomShows
} from './lib/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Tv, Sparkles, Filter, Search, RotateCw, Heart, Calendar, 
  Clock, ArrowRight, Trash2, HeartHandshake, HelpCircle, 
  TrendingUp, RefreshCcw, LogIn, ChevronRight, Check, Star,
  AlertTriangle, Plus, ShieldCheck, ExternalLink, EyeOff, Eye
} from 'lucide-react';
import { PopularShowCard } from './components/PopularShowCard';

// Static Popular shows details
const POPULAR_GRID = [
  { name: 'Breaking Bad', count: 62 },
  { name: 'The Office', count: 201 },
  { name: 'Friends', count: 236 },
  { name: 'Stranger Things', count: 34 },
  { name: 'Brooklyn Nine-Nine', count: 153 },
  { name: 'Sherlock', count: 13 }
];

function stripHtml(html: string) {
  if (!html) return '';
  return html.replace(/<[^>]*>/g, '').trim();
}

function RandomizeApp() {
  const [activePage, setActivePage] = useState('home');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);

  // Search and show states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedShow, setSelectedShow] = useState<TVShow | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Suggestions/Autocomplete state
  const [suggestions, setSuggestions] = useState<{ id: number; name: string; premiered?: string; image?: string; genres?: string[] }[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  // Custom Show Profiles state
  const [customShows, setCustomShows] = useState<CustomShow[]>([]);
  const [selectedCustomShow, setSelectedCustomShow] = useState<CustomShow | null>(null);
  const [activeCustomEpisode, setActiveCustomEpisode] = useState<{ season: number; number: number } | null>(null);
  
  // Custom Profile Creation Form states
  const [customShowNameInput, setCustomShowNameInput] = useState('');
  const [customSeasonsInput, setCustomSeasonsInput] = useState(5);
  const [customEpisodesInput, setCustomEpisodesInput] = useState(10);
  const [customSummaryInput, setCustomSummaryInput] = useState('');
  const [customGenreInput, setCustomGenreInput] = useState('Drama');
  const [customYearInput, setCustomYearInput] = useState(new Date().getFullYear().toString());
  
  const [isFactChecking, setIsFactChecking] = useState(false);
  const [factCheckError, setFactCheckError] = useState<string | null>(null);
  const [factCheckAlert, setFactCheckAlert] = useState<{ isReal: boolean; message: string } | null>(null);

  // Filters state
  const [seasonFrom, setSeasonFrom] = useState<number>(1);
  const [seasonTo, setSeasonTo] = useState<number>(1);
  const [ratingFilter, setRatingFilter] = useState<number>(0);

  // Preference state
  const [showEpisodeDetails, setShowEpisodeDetails] = useState<boolean>(() => {
    const saved = localStorage.getItem('randomize-show-episode-details');
    return saved !== null ? saved === 'true' : true;
  });

  // Sync preference to local storage
  useEffect(() => {
    localStorage.setItem('randomize-show-episode-details', String(showEpisodeDetails));
  }, [showEpisodeDetails]);

  // Spun result state
  const [activeEpisode, setActiveEpisode] = useState<Episode | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinCount, setSpinCount] = useState(0);

  // Favorites state
  const [favorites, setFavorites] = useState<Favorite[]>([]);

  // Polling key for reviews component
  const [reviewRefreshKey, setReviewRefreshKey] = useState(0);

  // Load custom profiles from Firestore and local storage
  const loadCustomShows = async (user: FirebaseUser | null) => {
    let syncedShows: CustomShow[] = [];
    if (user) {
      try {
        syncedShows = await fetchAllCustomShows();
      } catch (err) {
        console.error("Error loading custom shows:", err);
      }
    }
    
    const localShowsRaw = localStorage.getItem('randomize-local-custom-shows');
    const localShows = localShowsRaw ? JSON.parse(localShowsRaw) : [];
    
    // Merge uniquely by ID
    const merged = [...syncedShows];
    localShows.forEach((ls: CustomShow) => {
      if (!merged.some(ms => ms.id === ls.id)) {
        merged.push(ls);
      }
    });

    setCustomShows(merged);
  };

  // Track state of Auth
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      loadCustomShows(user);
      if (user) {
        // Load user favorites from firestore
        try {
          const fbFavorites = await fetchUserFavorites(user.uid);
          setFavorites(fbFavorites);
        } catch (err) {
          console.error("Error loading synced favorites:", err);
        }
      } else {
        // Fallback to local storage for guests
        const localFavs = localStorage.getItem('randomize-local-favorites');
        setFavorites(localFavs ? JSON.parse(localFavs) : []);
      }
    });
    return unsub;
  }, []);

  // Sync guest favorites to local storage
  useEffect(() => {
    if (!currentUser) {
      localStorage.setItem('randomize-local-favorites', JSON.stringify(favorites));
    }
  }, [favorites, currentUser]);

  // Sync guest custom shows to local storage
  useEffect(() => {
    if (!currentUser) {
      const guestShows = customShows.filter(cs => cs.userId === 'guest');
      localStorage.setItem('randomize-local-custom-shows', JSON.stringify(guestShows));
    }
  }, [customShows, currentUser]);

  // Handle click-outside of autocomplete list
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const container = document.getElementById('search-engine-wrapper');
      if (container && !container.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Live TV show suggestions debounced search
  useEffect(() => {
    if (!isTyping || !searchQuery.trim() || searchQuery.length < 2) {
      setSuggestions([]);
      setShowDropdown(false);
      return;
    }

    const delayDebounce = setTimeout(async () => {
      try {
        const res = await fetch(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(searchQuery)}`);
        if (res.ok) {
          const data = await res.json();
          const parsed = data.map((item: any) => ({
            id: item.show.id,
            name: item.show.name,
            premiered: item.show.premiered ? item.show.premiered.slice(0, 4) : undefined,
            image: item.show.image ? item.show.image.medium : undefined,
            genres: item.show.genres || []
          }));
          setSuggestions(parsed.slice(0, 8)); // Top 8 limit
          setShowDropdown(parsed.length > 0);
        }
      } catch (err) {
        console.error("Error fetching suggestions:", err);
      }
    }, 250);

    return () => clearTimeout(delayDebounce);
  }, [searchQuery, isTyping]);

  const handleSelectSuggestion = (showName: string) => {
    setSearchQuery(showName);
    setIsTyping(false);
    setSuggestions([]);
    setShowDropdown(false);
    handleSearchShow(showName);
  };

  // Handle tvmaze looking up
  const handleSearchShow = async (queryName: string) => {
    if (!queryName.trim()) return;
    setIsSearching(true);
    setSearchError(null);
    try {
      const res = await fetch(`https://api.tvmaze.com/singlesearch/shows?q=${encodeURIComponent(queryName)}&embed=episodes`);
      if (res.status === 404) {
        throw new Error(`We couldn't find any TV Show matching "${queryName}". Try another title.`);
      }
      if (!res.ok) {
        throw new Error('TVMaze is taking too long to respond. Please try again.');
      }
      const data = await res.json();
      const rawEps = (data._embedded && data._embedded.episodes) as any[] || [];
      const cleanEps = rawEps.filter(e => e.season != null && e.number != null);

      if (cleanEps.length === 0) {
        throw new Error(`The show "${data.name}" was found, but there are no episodes listed yet.`);
      }

      const parsedShow: TVShow = {
        id: data.id,
        name: data.name,
        summary: stripHtml(data.summary),
        image: data.image ? (data.image.original || data.image.medium) : null,
        premiered: data.premiered ? data.premiered.slice(0, 4) : '—',
        ended: data.ended ? data.ended.slice(0, 4) : null,
        network: (data.network && data.network.name) || (data.webChannel && data.webChannel.name) || '—',
        genres: data.genres || [],
        imdbId: (data.externals && data.externals.imdb) || null
      };

      setSelectedShow(parsedShow);
      setEpisodes(cleanEps);

      // Reset filter limits
      const seasons = Array.from(new Set(cleanEps.map((e: any) => e.season))).sort((a: any, b: any) => a - b) as number[];
      setSeasonFrom(seasons[0] || 1);
      setSeasonTo(seasons[seasons.length - 1] || 1);
      setRatingFilter(0);

      // Reset result
      setActiveEpisode(null);

      // Clear suggestions autocomplete state
      setIsTyping(false);
      setSuggestions([]);
      setShowDropdown(false);

      // Auto-scroll to show's randomizer panel beautifully
      setTimeout(() => {
        const controlsEl = document.getElementById('controlsPanel');
        if (controlsEl) {
          controlsEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 150);

    } catch (err: any) {
      console.error(err);
      setSearchError(err.message || 'An unexpected error occurred during search.');
    } finally {
      setIsSearching(false);
    }
  };

  // Perform randomize calculation
  const handleRandomize = async () => {
    if (!selectedShow || episodes.length === 0) return;

    // Filter by season range and TVMaze episode rating average
    let pool = episodes.filter(ep => {
      const matchSeason = ep.season >= seasonFrom && ep.season <= seasonTo;
      if (!matchSeason) return false;

      if (ratingFilter > 0) {
        const ratingAvg = ep.rating?.average;
        return ratingAvg != null && ratingAvg >= ratingFilter;
      }
      return true;
    });

    if (pool.length === 0) {
      if (ratingFilter > 0) {
        alert(`No episodes matched your selection. Try lowering the TVMaze Rating filter (currently ≥ ${ratingFilter}) or expanding your season range.`);
      } else {
        alert("No episodes found in the selected season range.");
      }
      return;
    }

    setIsSpinning(true);
    // Increase spin counter to animate Odometer
    setSpinCount(prev => prev + 1);

    // Pick random target
    const randomEpisode = pool[Math.floor(Math.random() * pool.length)];

    // Wait 1.2s to simulate Odometer spinner scrolling
    setTimeout(() => {
      setActiveEpisode(randomEpisode);
      setIsSpinning(false);
      
      // Auto-scroll to results beautifully
      setTimeout(() => {
        const resEl = document.getElementById('result-panel-scroll-anchor');
        if (resEl) {
          resEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }, 1100);
  };

  // Perform randomize calculation for Custom Shows
  const handleRandomizeCustom = async () => {
    if (!selectedCustomShow) return;

    setIsSpinning(true);
    setSpinCount(prev => prev + 1);

    // Pick random target season and episode within limits of the custom show
    const randomSeason = Math.floor(Math.random() * selectedCustomShow.seasons) + 1;
    const randomEpisode = Math.floor(Math.random() * selectedCustomShow.episodesPerSeason) + 1;

    setTimeout(() => {
      setActiveCustomEpisode({ season: randomSeason, number: randomEpisode });
      setIsSpinning(false);

      // Auto-scroll to custom results beautifully
      setTimeout(() => {
        const resEl = document.getElementById('custom-result-panel');
        if (resEl) {
          resEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }, 1100);
  };

  // AI Fact-Checking with Gemini
  const handleFactCheck = async () => {
    if (!customShowNameInput.trim()) {
      setFactCheckError("Please enter a show name to fact-check.");
      return;
    }

    setIsFactChecking(true);
    setFactCheckError(null);
    setFactCheckAlert(null);

    try {
      const res = await fetch('/api/fact-check', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ showName: customShowNameInput })
      });

      if (!res.ok) {
        throw new Error("AI Fact-Checking server failed to process request.");
      }

      const data = await res.json();

      // Auto-populate form fields
      setCustomShowNameInput(data.officialName || customShowNameInput);
      setCustomSeasonsInput(data.totalSeasons || 1);
      setCustomEpisodesInput(data.episodesPerSeasonUniform || 10);
      setCustomSummaryInput(data.summary || '');
      setCustomGenreInput(data.genre || 'Drama');
      setCustomYearInput(data.premieredYear || new Date().getFullYear().toString());

      setFactCheckAlert({
        isReal: data.isReal,
        message: data.warningMessage || (data.isReal 
          ? `Verified! We found "${data.officialName}" in real-world catalogs. Automatically populated accurate show specifications.`
          : `Custom Profile: We couldn't find a direct real-world match for "${customShowNameInput}". You can still build this completely custom profile below.`)
      });
    } catch (err: any) {
      console.error(err);
      setFactCheckError(err.message || "An error occurred during AI Fact-Checking.");
    } finally {
      setIsFactChecking(false);
    }
  };

  // Create new Custom Show Profile
  const handleCreateCustomShow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customShowNameInput.trim()) return;

    const showId = 'custom_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 5);

    const newShow: CustomShow = {
      id: showId,
      userId: currentUser?.uid || 'guest',
      name: customShowNameInput.trim(),
      seasons: customSeasonsInput || 5,
      episodesPerSeason: customEpisodesInput || 10,
      summary: customSummaryInput.trim() || 'A user-created custom show profile.',
      genre: customGenreInput,
      premieredYear: customYearInput || '—',
      createdAt: new Date().toISOString()
    };

    // Save to State
    const updatedShows = [newShow, ...customShows];
    setCustomShows(updatedShows);

    // Save to Firestore if signed in
    if (currentUser) {
      try {
        await saveCustomShow(newShow);
      } catch (err) {
        console.error("Failed to save custom show to Firestore:", err);
      }
    } else {
      const guestShows = updatedShows.filter(cs => cs.userId === 'guest');
      localStorage.setItem('randomize-local-custom-shows', JSON.stringify(guestShows));
    }

    // Select this created show
    setSelectedCustomShow(newShow);
    setActiveCustomEpisode(null);

    // Reset Creation form fields
    setCustomShowNameInput('');
    setCustomSummaryInput('');
    setCustomSeasonsInput(5);
    setCustomEpisodesInput(10);
    setFactCheckAlert(null);
  };

  // Delete Custom Show Profile
  const handleDeleteCustomShow = async (showId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = customShows.filter(cs => cs.id !== showId);
    setCustomShows(updated);

    if (selectedCustomShow?.id === showId) {
      setSelectedCustomShow(null);
      setActiveCustomEpisode(null);
    }

    if (currentUser) {
      try {
        await deleteCustomShow(showId);
      } catch (err) {
        console.error("Failed to delete custom show from Firestore:", err);
      }
    } else {
      const guestShows = updated.filter(cs => cs.userId === 'guest');
      localStorage.setItem('randomize-local-custom-shows', JSON.stringify(guestShows));
    }
  };

  // Manage internal client-side and firestore favorites sync
  const isFavorited = (ep: Episode) => {
    if (!selectedShow) return false;
    const computedKey = `${selectedShow.name}__S${ep.season}E${ep.number}`;
    return favorites.some(fav => fav.id === computedKey);
  };

  const handleToggleFavorite = async (ep: Episode) => {
    if (!selectedShow) return;
    const computedKey = `${selectedShow.name}__S${ep.season}E${ep.number}`;

    if (isFavorited(ep)) {
      // Remove favorite
      const updated = favorites.filter(fav => fav.id !== computedKey);
      setFavorites(updated);
      
      if (currentUser) {
        try {
          await deleteFavoriteEpisode(computedKey);
        } catch (e) {
          console.error("Error unsaving favorite:", e);
        }
      }
    } else {
      // Add favorite
      const newFav: Favorite = {
        id: computedKey,
        userId: currentUser?.uid || 'guest',
        showName: selectedShow.name,
        season: ep.season,
        number: ep.number,
        title: ep.name || `Episode ${ep.number}`,
        image: ep.image ? ep.image.medium : null,
        airdate: ep.airdate || '',
        createdAt: new Date().toISOString()
      };

      setFavorites([newFav, ...favorites]);

      if (currentUser) {
        try {
          await saveFavoriteEpisode(newFav);
        } catch (e) {
          console.error("Error saving favorite:", e);
        }
      }
    }
  };

  const handleRemoveFavoriteByKey = async (key: string) => {
    setFavorites(favorites.filter(fav => fav.id !== key));
    if (currentUser) {
      try {
        await deleteFavoriteEpisode(key);
      } catch (e) {
        console.error("Error unsaving favorite key:", e);
      }
    }
  };

  // Computed seasons list
  const seasonsList = (Array.from(new Set(episodes.map(e => e.season))) as number[]).sort((a: number, b: number) => a - b);

  return (
    <div className="min-h-screen flex flex-col justify-between">
      {/* Navigation Header */}
      <Navbar 
        activePage={activePage} 
        setActivePage={setActivePage} 
        onOpenAuthModal={() => setAuthModalOpen(true)} 
      />

      {/* Main body content */}
      <main className="flex-1 max-w-[1180px] w-full mx-auto px-6 py-8 md:py-12">
        <AnimatePresence mode="wait">
          {/* HOME PAGE */}
          {activePage === 'home' && (
            <motion.div
              key="home-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="space-y-12"
            >
              {/* Hero Segment */}
              <section className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-center">
                <div className="md:col-span-7 space-y-6 text-left">
                  <h1 className="text-4xl sm:text-5xl font-display font-extrabold tracking-tight leading-[1.1] text-gray-900 dark:text-[#F2F0FA] transition-colors">
                    Can't decide what <span className="grad text-transparent bg-clip-text font-black">episode</span> to watch?
                  </h1>
                  <p className="text-gray-500 dark:text-[#9690B8] text-base sm:text-lg max-w-[500px]">
                    Let Randomize pick the perfect episode instantly. Skip decision fatigue, filter by seasons, read real community ratings, and start watching.
                  </p>

                  {/* Search Engine UI */}
                  <div className="relative max-w-[540px]" id="search-engine-wrapper">
                    <div className="panel p-2 flex flex-col sm:flex-row items-center gap-2 border-white/5 bg-white/5">
                      <div className="flex items-center gap-3 flex-1 w-full pl-3 pr-2 py-1.5 min-w-0">
                        <Search className="w-5 h-5 text-gray-500 shrink-0" />
                        <input 
                          type="text" 
                          value={searchQuery}
                          onChange={(e) => {
                            setSearchQuery(e.target.value);
                            setIsTyping(true);
                          }}
                          onFocus={() => {
                            if (searchQuery.trim().length >= 2) {
                              setIsTyping(true);
                              setShowDropdown(true);
                            }
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSearchShow(searchQuery);
                          }}
                          placeholder="Search any TV show (e.g., Breaking Bad, Friends)..."
                          className="bg-transparent border-0 outline-none w-full text-sm placeholder-gray-500 text-gray-900 dark:text-[#F2F0FA]"
                        />
                      </div>
                      <button
                        onClick={() => handleSearchShow(searchQuery)}
                        disabled={isSearching}
                        className="w-full sm:w-auto bg-gradient-to-r from-[var(--violet)] to-[var(--magenta)] text-white px-6 py-3 rounded-xl font-bold font-sans text-sm hover:brightness-105 active:scale-[0.98] cursor-pointer transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-[var(--violet)]/20"
                      >
                        {isSearching ? (
                          <>
                            <RefreshCcw className="w-4 h-4 animate-spin" />
                            Searching...
                          </>
                        ) : (
                          'Let\'s Randomize'
                        )}
                      </button>
                    </div>

                    {/* Auto-suggest dropdown menu */}
                    {showDropdown && suggestions.length > 0 && (
                      <div className="absolute left-0 right-0 mt-2 bg-[#12111a] border border-white/10 rounded-2xl shadow-2xl p-2 z-40 max-h-[320px] overflow-y-auto divide-y divide-white/5 animate-scaleUp">
                        {suggestions.map((show) => (
                          <div
                            key={show.id}
                            onClick={() => handleSelectSuggestion(show.name)}
                            className="flex items-center gap-3 p-2.5 hover:bg-white/5 rounded-xl cursor-pointer transition-colors text-left group"
                          >
                            {show.image ? (
                              <img
                                src={show.image}
                                alt={show.name}
                                referrerPolicy="no-referrer"
                                className="w-9 h-12 object-cover rounded-lg bg-gray-800 shrink-0"
                              />
                            ) : (
                              <div className="w-9 h-12 bg-white/5 border border-white/5 rounded-lg flex items-center justify-center shrink-0">
                                <Tv className="w-4.5 h-4.5 text-gray-400" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <h4 className="font-bold text-sm text-[#F2F0FA] truncate group-hover:text-[var(--violet)] transition-colors">
                                {show.name}
                              </h4>
                              {show.genres.length > 0 && (
                                <p className="text-[10px] font-mono text-gray-500 truncate mt-0.5">
                                  {show.genres.join(', ')}
                                </p>
                              )}
                            </div>
                            {show.premiered && (
                              <span className="text-[10px] font-mono text-gray-400 bg-white/5 px-2 py-0.5 rounded border border-white/10 shrink-0">
                                {show.premiered}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {searchError && (
                    <p className="text-xs text-red-500 dark:text-red-400 font-mono" id="search-error-message">
                      ⚠️ {searchError}
                    </p>
                  )}
                </div>

                {/* Pulsing Visual Artwork */}
                <div className="md:col-span-5 relative flex justify-center items-center py-6 select-none" aria-hidden="true">
                  {/* Neon Glow backdrop */}
                  <div className="absolute w-[240px] h-[240px] bg-[var(--violet)]/20 dark:bg-[var(--violet)]/15 rounded-full blur-[80px]" />
                  <div className="absolute w-[200px] h-[200px] bg-[var(--magenta)]/20 dark:bg-[var(--magenta)]/10 rounded-full blur-[70px] -bottom-4" />

                  {/* Retro TV model */}
                  <div className="relative w-[210px] h-[155px] bg-[#101010] border border-white/5 rounded-[18px] shadow-2xl flex items-center justify-center transform hover:rotate-2 transition-all">
                    {/* Screen reflection */}
                    <div className="absolute inset-2.5 rounded-[12px] bg-gradient-to-tr from-[var(--violet)] via-[var(--magenta)] to-[var(--violet)] bg-[size:200%_200%] animate-[shimmer_6s_infinite_linear] opacity-80" />
                    {/* Retro antenna */}
                    <div className="absolute -top-7 left-1/3 -rotate-[22deg] w-12 h-0.5 bg-gray-500 rounded-fullOrigin transform origin-bottom-right" />
                    <div className="absolute -top-7 right-1/3 rotate-[22deg] w-12 h-0.5 bg-gray-500 rounded-fullOrigin transform origin-bottom-left" />
                  </div>

                  {/* Aesthetic sparkles */}
                  <div className="absolute top-4 left-6 text-purple-400 animate-pulse"><Sparkles className="w-4 h-4" /></div>
                  <div className="absolute bottom-1 right-8 text-pink-400 animate-pulse delay-100"><Sparkles className="w-5 h-5" /></div>
                </div>
              </section>

              {/* Unique Bento Layout Features list */}
              <section className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                <div className="panel p-5 text-left border-white/5 bg-white/5 hover:border-[var(--violet)]/30 transition-all">
                  <div className="w-10 h-10 rounded-xl bg-[var(--violet)]/10 flex items-center justify-center text-[var(--violet)] mb-4">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <h3 className="text-gray-900 dark:text-[#F2F0FA] font-bold text-base mb-1">Decide Instantly</h3>
                  <p className="text-gray-500 dark:text-gray-400 text-xs leading-relaxed">Spins an episode at random in 1-click. Ideal for background loops or rewatching.</p>
                </div>

                <div className="panel p-5 text-left border-white/5 bg-white/5 hover:border-[var(--violet)]/30 transition-all">
                  <div className="w-10 h-10 rounded-xl bg-[var(--magenta)]/10 flex items-center justify-center text-[var(--magenta)] mb-4">
                    <Filter className="w-5 h-5" />
                  </div>
                  <h3 className="text-gray-900 dark:text-[#F2F0FA] font-bold text-base mb-1">Tailored Filters</h3>
                  <p className="text-gray-500 dark:text-gray-400 text-xs leading-relaxed">Limit your choices to classic early seasons or specific community reviews scores.</p>
                </div>

                <div 
                  onClick={() => setActivePage('custom')}
                  className="panel p-5 text-left border-white/5 bg-white/5 hover:border-[var(--violet)]/30 cursor-pointer hover:bg-white/10 transition-all group"
                >
                  <div className="w-10 h-10 rounded-xl bg-[var(--violet)]/10 flex items-center justify-center text-[var(--violet)] mb-4 group-hover:scale-105 transition-transform">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <h3 className="text-gray-900 dark:text-[#F2F0FA] font-bold text-base mb-1 flex items-center gap-1">
                    Custom TV Profiles
                    <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all text-[var(--violet)] shrink-0" />
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 text-xs leading-relaxed">Can't find a show? Draft custom seasons on our sandbox and randomize coordinates instantly with AI fact-checking.</p>
                </div>
              </section>

              {/* Popular Picks Scroller */}
              <section className="space-y-4">
                <div className="flex justify-between items-center text-left">
                  <div>
                    <h2 className="text-[#F2F0FA] font-display font-extrabold text-lg flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-[#7C5CFC]" />
                      Popular Picks
                    </h2>
                    <p className="text-xs text-gray-400">Instantly browse fan-favorite community shows</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                  {POPULAR_GRID.map((show, i) => (
                    <PopularShowCard
                      key={i}
                      name={show.name}
                      count={show.count}
                      onClick={() => {
                        setSearchQuery(show.name);
                        setIsTyping(false);
                        setSuggestions([]);
                        setShowDropdown(false);
                        handleSearchShow(show.name);
                      }}
                    />
                  ))}
                </div>
              </section>

              {/* Custom Profiles Showcase */}
              <section className="space-y-4 pt-4 border-t border-white/5 animate-fadeIn">
                <div className="flex justify-between items-end text-left">
                  <div className="space-y-1">
                    <h2 className="text-[#F2F0FA] font-display font-extrabold text-lg flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-[var(--magenta)]" />
                      Community Blueprints Hub
                    </h2>
                    <p className="text-xs text-gray-400">Custom user-authored show designs. No ratings limits!</p>
                  </div>
                  <button
                    onClick={() => setActivePage('custom')}
                    className="text-xs text-[var(--violet)] hover:underline font-bold font-sans flex items-center gap-1 cursor-pointer"
                  >
                    Manage Custom Profiles
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {customShows.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    {customShows.slice(0, 4).map((show) => (
                      <div
                        key={show.id}
                        onClick={() => {
                          setSelectedCustomShow(show);
                          setActiveCustomEpisode(null);
                          setActivePage('custom');
                          // Smooth scroll after click
                          setTimeout(() => {
                            const anchor = document.getElementById('custom-randomizer-anchor');
                            if (anchor) anchor.scrollIntoView({ behavior: 'smooth' });
                          }, 150);
                        }}
                        className="p-4 bg-white/5 border border-white/5 hover:border-[var(--violet)]/50 rounded-2xl cursor-pointer text-left hover:bg-white/10 transition-all flex flex-col justify-between h-36 group"
                      >
                        <div>
                          <div className="flex justify-between items-start">
                            <span className="text-[9px] font-mono font-bold tracking-wider text-[var(--magenta)] uppercase">
                              {show.genre}
                            </span>
                            <span className="text-[9px] font-mono text-gray-500">
                              {show.premieredYear}
                            </span>
                          </div>
                          <h4 className="font-bold text-sm text-[#F2F0FA] truncate mt-1 group-hover:text-[var(--violet)] transition-colors">
                            {show.name}
                          </h4>
                          <p className="text-[11px] text-gray-400 line-clamp-2 leading-relaxed mt-1">
                            {show.summary}
                          </p>
                        </div>
                        <div className="text-[10px] font-mono text-gray-500 flex justify-between pt-2 border-t border-white/5">
                          <span>{show.seasons} Seasons</span>
                          <span>{show.episodesPerSeason} Ep/s</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="panel p-8 text-center bg-white/5 border-white/5 rounded-2xl flex flex-col items-center gap-3">
                    <Tv className="w-8 h-8 text-gray-400 dark:text-gray-500 stroke-1" />
                    <div className="space-y-1">
                      <p className="text-xs text-[#F2F0FA] font-bold">No custom blueprints active yet</p>
                      <p className="text-[11px] text-gray-500">Be the first to draft a custom profile catalog using server AI!</p>
                    </div>
                    <button
                      onClick={() => setActivePage('custom')}
                      className="px-3.5 py-1.5 rounded-xl bg-[var(--violet)]/10 text-[var(--violet)] text-xs font-bold border border-[var(--violet)]/20 hover:bg-[var(--violet)]/20 cursor-pointer"
                    >
                      Draft Custom Show
                    </button>
                  </div>
                )}
              </section>

              {/* SELECTION SHOW & CONTROLS CONTAINER */}
              {selectedShow && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-5" id="controlsPanel">
                  {/* Show summary card (left side) */}
                  <div className="md:col-span-5">
                    <div className="panel p-5 text-left space-y-4 bg-white/5 border-white/5 sticky top-24">
                      <p className="text-[10px] uppercase tracking-wider font-mono text-[var(--violet)] font-extrabold">SELECTED SHOW</p>
                      
                      <div className="flex gap-4">
                        {selectedShow.image ? (
                          <img 
                            src={selectedShow.image} 
                            alt={selectedShow.name} 
                            className="w-20 md:w-24 h-28 md:h-34 object-cover rounded-xl border border-white/10 shrink-0 shadow-lg"
                          />
                        ) : (
                          <div className="w-20 md:w-24 h-28 md:h-34 rounded-xl bg-[#161616] border border-dashed border-white/15 flex items-center justify-center shrink-0">
                            <Tv className="w-6 h-6 text-gray-500" />
                          </div>
                        )}
                        <div className="space-y-1 min-w-0">
                          <h2 className="text-gray-950 dark:text-[#F2F0FA] font-display font-extrabold text-xl leading-tight truncate">
                            {selectedShow.name}
                          </h2>
                          <p className="text-xs text-[var(--violet)] font-semibold font-mono pb-1">
                            {episodes.length} episodes · {seasonsList.length} season{seasonsList.length === 1 ? '' : 's'}
                          </p>
                          <div className="flex flex-wrap gap-1.5 pt-0.5 items-center">
                            {selectedShow.genres.slice(0, 3).map((g, gi) => (
                              <span key={gi} className="text-[8px] sm:text-[9px] font-mono text-gray-500 dark:text-gray-400 border border-white/10 rounded-full px-2 py-0.5 bg-white/5">
                                {g}
                              </span>
                            ))}
                            {selectedShow.imdbId && (
                              <a 
                                href={`https://www.imdb.com/title/${selectedShow.imdbId}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-[8px] sm:text-[9px] font-mono font-bold bg-[#F5C518] hover:bg-[#E2B616] text-black px-2 py-0.5 rounded transition-all shadow-sm"
                                title="View on IMDb"
                              >
                                <Star className="w-2.5 h-2.5 fill-black text-black" />
                                IMDb
                              </a>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-white/5 pt-3 text-xs text-gray-500 dark:text-gray-400 space-y-2">
                        <p className="font-sans leading-relaxed line-clamp-4">
                          {selectedShow.summary || 'No overview available for this show.'}
                        </p>
                        <div className="grid grid-cols-2 gap-2 text-[10px] font-mono pt-1 text-gray-400 dark:text-gray-500">
                          <div>PREMIERED: <span className="text-gray-900 dark:text-gray-300">{selectedShow.premiered}</span></div>
                          <div>NETWORK: <span className="text-gray-900 dark:text-gray-300 truncate block sm:inline">{selectedShow.network}</span></div>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedShow(null);
                          setEpisodes([]);
                          setActiveEpisode(null);
                          setSearchQuery('');
                        }}
                        className="w-full text-center py-2 border border-white/15 text-gray-900 dark:text-[#F2F0FA] hover:text-[var(--violet)] hover:border-[var(--violet)] rounded-lg text-xs font-semibold cursor-pointer transition-colors bg-white/5"
                      >
                        Search different TV show
                      </button>
                    </div>
                  </div>

                  {/* Filters & trigger action card (right side) */}
                  <div className="md:col-span-7">
                    <div className="panel p-6 text-left space-y-6">
                      <p className="text-[10px] uppercase tracking-wider font-mono text-[#C66DF2] font-semibold">TUNE RANDOMIZATION</p>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-wide">FROM SEASON</label>
                          <select 
                            value={seasonFrom}
                            onChange={(e) => {
                              const v = parseInt(e.target.value, 10);
                              setSeasonFrom(v);
                              if (v > seasonTo) setSeasonTo(v);
                            }}
                            className="w-full bg-[#161616] light:bg-[#FAF9F6] border border-white/10 rounded-xl text-sm p-3 text-gray-900 dark:text-[#F2F0FA] font-mono focus:outline-none focus:border-[var(--violet)]"
                          >
                            {seasonsList.map((s) => (
                              <option key={s} value={s}>Season {s}</option>
                            ))}
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[10px] font-mono text-gray-500 dark:text-gray-400 uppercase tracking-wide">TO SEASON</label>
                          <select 
                            value={seasonTo}
                            onChange={(e) => setSeasonTo(parseInt(e.target.value, 10))}
                            className="w-full bg-[#161616] light:bg-[#FAF9F6] border border-white/10 rounded-xl text-sm p-3 text-gray-900 dark:text-[#F2F0FA] font-mono focus:outline-none focus:border-[var(--violet)]"
                          >
                            {seasonsList.filter(s => s >= seasonFrom).map((s) => (
                              <option key={s} value={s}>Season {s}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-gray-500 dark:text-gray-400 font-mono uppercase tracking-wide text-[10px]">Filter by TVMaze Rating</span>
                            <span className="text-[var(--magenta)] font-bold font-mono">
                              {ratingFilter === 0 ? 'Disabled (All Episodes)' : `≥ ${ratingFilter} Stars`}
                            </span>
                          </div>
                          <p className="text-[10px] text-gray-500 dark:text-gray-400 mt-0.5">Allows only episodes with TVMaze rating scores matching or exceeding selected value.</p>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="9.5"
                          step="0.5"
                          value={ratingFilter}
                          onChange={(e) => setRatingFilter(parseFloat(e.target.value))}
                          className="w-full accent-[var(--magenta)] h-1.5 bg-[#161616] rounded-lg cursor-pointer"
                        />
                        {/* Dynamic rating-match feedback warning */}
                        {(() => {
                          const matchingPool = episodes.filter(ep => {
                            const matchSeason = ep.season >= seasonFrom && ep.season <= seasonTo;
                            if (!matchSeason) return false;
                            if (ratingFilter > 0) {
                              const ratingAvg = ep.rating?.average;
                              return ratingAvg != null && ratingAvg >= ratingFilter;
                            }
                            return true;
                          });
                          
                          const seasonPool = episodes.filter(ep => ep.season >= seasonFrom && ep.season <= seasonTo);
                          const maxRatingInSeasonPool = seasonPool.length > 0 
                            ? Math.max(...seasonPool.map(ep => ep.rating?.average || 0)) 
                            : 0;

                          if (ratingFilter > 0 && matchingPool.length === 0) {
                            return (
                              <div className="bg-amber-500/10 border border-amber-500/25 rounded-xl p-3.5 mt-3 space-y-1.5 animate-fadeIn">
                                <span className="flex items-center gap-1.5 font-bold text-xs text-amber-400 font-sans">
                                  <AlertTriangle className="w-4 h-4 shrink-0" />
                                  No Episodes Match This Rating Filter
                                </span>
                                <p className="text-[11px] text-gray-400 leading-relaxed font-sans">
                                  None of the episodes in Season {seasonFrom === seasonTo ? seasonFrom : `${seasonFrom} to ${seasonTo}`} have a rating of <strong className="text-amber-300">≥ {ratingFilter} Stars</strong>.
                                  {maxRatingInSeasonPool > 0 && (
                                    <> The highest rated episode in this range is <strong className="text-white bg-white/10 px-1.5 py-0.5 rounded font-mono font-bold leading-none">{maxRatingInSeasonPool} Stars</strong>.</>
                                  )} Please reduce your filter or expand your season selection so we can randomize.
                                </p>
                              </div>
                            );
                          }
                          return null;
                        })()}
                      </div>

                      <div className="flex items-center justify-between p-3.5 bg-white/5 border border-white/5 rounded-xl transition-all">
                        <div className="space-y-0.5">
                          <span className="text-[#F2F0FA] font-bold text-xs block">Reveal Episode Details</span>
                          <span className="text-[10px] text-gray-400 block leading-normal">
                            Show description, rating, synopsis and poster thumbnail after spin
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowEpisodeDetails(!showEpisodeDetails)}
                          className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                            showEpisodeDetails ? 'bg-[var(--violet)]' : 'bg-gray-800'
                          }`}
                        >
                          <span
                            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                              showEpisodeDetails ? 'translate-x-[20px]' : 'translate-x-0'
                            }`}
                          />
                        </button>
                      </div>

                      <hr className="border-white/5" />

                      <div className="w-full text-center">
                        <button
                          onClick={handleRandomize}
                          disabled={isSpinning}
                          className="btn-randomise bg-gradient-to-r from-[var(--violet)] to-[var(--magenta)] text-white py-4 px-12 rounded-2xl font-bold text-lg hover:brightness-105 active:scale-[0.98] transition-all duration-150 relative cursor-pointer shadow-lg shadow-[var(--violet)]/25 disabled:opacity-40"
                          style={{ fontFamily: '"Sora", sans-serif' }}
                        >
                          {isSpinning ? 'SPINNING CYLINDERS...' : 'Randomize Episode'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* SPUN OUT RESULTS SEGMENT */}
              <div id="result-panel-scroll-anchor" className="scroll-mt-24" />
              
              {/* Spinning/Loader overlay overlay */}
              {isSpinning && (
                <div className="py-12 text-center space-y-4">
                  <div className="inline-flex gap-2.5 items-center justify-center">
                    <span className="w-3 h-3 rounded-full bg-[#7C5CFC] animate-bounce" />
                    <span className="w-3 h-3 rounded-full bg-[#C66DF2] animate-bounce delay-100" />
                    <span className="w-3 h-3 rounded-full bg-[#7C5CFC] animate-bounce delay-200" />
                  </div>
                  <h3 className="font-mono text-xs text-gray-400 uppercase tracking-widest leading-none">Scouring active TVMaze schedules...</h3>
                </div>
              )}

              <AnimatePresence>
                {!isSpinning && activeEpisode && selectedShow && (
                  <motion.section
                    initial={{ opacity: 0, scale: 0.98, y: 15 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, y: 15 }}
                    transition={{ type: 'spring', duration: 0.4 }}
                    className="max-w-[760px] mx-auto space-y-5 text-center mt-12"
                    id="resultPanel"
                  >
                    {/* Odometer spinners */}
                    <div className="flex justify-center gap-10 bg-[#101010] p-4 border border-white/5 rounded-2xl shadow-xl w-fit mx-auto">
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-semibold block">SEASON</span>
                        <Odometer value={activeEpisode.season} digits={2} />
                      </div>
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-semibold block">EPISODE</span>
                        <Odometer value={activeEpisode.number} digits={2} />
                      </div>
                    </div>

                     {/* Result Ticket layout item */}
                    {showEpisodeDetails ? (
                      <div className="panel p-5 sm:p-7 text-left flex flex-col sm:flex-row gap-6 border-white/5 bg-[#101010]">
                        {activeEpisode.image ? (
                          <img 
                            src={activeEpisode.image.medium} 
                            alt={activeEpisode.name} 
                            className="w-full sm:w-44 h-44 sm:h-56 object-cover rounded-xl border border-white/10 shrink-0 shadow-lg"
                          />
                        ) : (
                          <div className="w-full sm:w-44 h-44 sm:h-56 rounded-xl bg-gradient-to-tr from-[var(--violet)]/10 to-[var(--magenta)]/10 border border-dashed border-white/10 flex flex-col items-center justify-center shrink-0">
                            <Tv className="w-8 h-8 text-purple-400 stroke-1 mb-2" />
                            <span className="text-xs text-gray-500 font-semibold">Image Unavailable</span>
                          </div>
                        )}

                        <div className="flex-1 space-y-4 min-w-0">
                          <div className="space-y-1">
                            <h3 className="text-[#F2F0FA] font-display font-black text-2xl truncate">
                              {activeEpisode.name || `Episode ${activeEpisode.number}`}
                            </h3>
                            <div className="flex flex-wrap items-center gap-3 text-xs font-mono text-[#7C5CFC] font-semibold">
                              <span>S{activeEpisode.season} · E{activeEpisode.number}</span>
                              {activeEpisode.rating?.average != null && (
                                <span className="flex items-center gap-1 bg-[var(--violet)]/10 text-[var(--violet)] px-2 py-0.5 rounded font-bold">
                                  <Star className="w-3.5 h-3.5 fill-current" />
                                  {activeEpisode.rating.average}/10 (TVMaze)
                                </span>
                              )}
                              {activeEpisode.airdate && (
                                <span className="flex items-center gap-1.5 text-gray-500 font-sans font-light">
                                  <Calendar className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                                  Aired {activeEpisode.airdate}
                                </span>
                              )}
                              {activeEpisode.runtime && (
                                <span className="flex items-center gap-1.5 text-gray-500 font-sans font-light">
                                  <Clock className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                                  {activeEpisode.runtime} min
                                </span>
                              )}
                            </div>
                          </div>

                          <p className="text-sm text-gray-400 leading-relaxed font-sans line-clamp-5">
                            {activeEpisode.summary ? stripHtml(activeEpisode.summary) : 'No description provided for this episode.'}
                          </p>

                          <div className="flex flex-wrap items-center gap-4 border-t border-white/5 pt-4">
                            {/* Heart favorite button */}
                            <button
                              onClick={() => handleToggleFavorite(activeEpisode)}
                              className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-bold transition-all cursor-pointer ${
                                isFavorited(activeEpisode)
                                  ? 'bg-pink-500/10 border-pink-500 text-pink-500 shadow-sm'
                                  : 'bg-white/5 border-white/10 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:border-[var(--violet)]'
                              }`}
                            >
                              <Heart className="w-4 h-4" fill={isFavorited(activeEpisode) ? "currentColor" : "none"} />
                              {isFavorited(activeEpisode) ? 'Saved to Favorites' : 'Save Episode'}
                            </button>

                            {/* Quick Spin again */}
                            <button
                              onClick={handleRandomize}
                              className="flex items-center gap-2 px-4 py-2 border border-white/15 hover:border-[var(--violet)] text-gray-700 dark:text-gray-300 hover:text-gray-950 dark:hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer bg-white/5"
                            >
                              <RotateCw className="w-4 h-4" />
                              Spin again
                            </button>

                            {/* Individual Episode Search on IMDb */}
                            <a
                              href={`https://www.imdb.com/find?q=${encodeURIComponent(selectedShow.name + ' S' + activeEpisode.season + 'E' + activeEpisode.number)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-4 py-2 border border-white/15 hover:border-[var(--violet)] text-gray-700 dark:text-gray-300 hover:text-gray-950 dark:hover:text-white rounded-xl text-xs font-bold transition-all bg-white/5"
                            >
                              <ExternalLink className="w-4 h-4" />
                              IMDb Search
                            </a>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="panel p-6 sm:p-8 text-center bg-[#101010] border-white/5 space-y-4 max-w-md mx-auto animate-fadeIn">
                        <div className="w-12 h-12 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 flex items-center justify-center mx-auto">
                          <EyeOff className="w-5 h-5" />
                        </div>
                        <div className="space-y-1">
                          <h3 className="text-[#F2F0FA] font-bold text-base">Episode Details Shrouded</h3>
                          <p className="text-gray-400 text-xs max-w-xs mx-auto leading-normal">
                            The title, description, and thumbnail of Season {activeEpisode.season} Episode {activeEpisode.number} are currently hidden.
                          </p>
                        </div>
                        
                        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                          <button
                            onClick={() => setShowEpisodeDetails(true)}
                            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[var(--violet)] text-white text-xs font-bold rounded-xl hover:brightness-105 active:scale-[0.98] transition-all cursor-pointer shadow-md"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Reveal Details
                          </button>
                          
                          <button
                            onClick={handleRandomize}
                            className="inline-flex items-center gap-1.5 px-4 py-2 border border-white/15 hover:border-[var(--violet)] text-gray-300 rounded-xl text-xs font-bold transition-all cursor-pointer bg-white/5"
                          >
                            <RotateCw className="w-3.5 h-3.5" />
                            Spin again
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Community Reviews & Score Box */}
                    <div className="panel p-6 border-white/5 bg-[#101010]">
                      {/* Form */}
                      <EpisodeReviewForm 
                        showName={selectedShow.name}
                        season={activeEpisode.season}
                        number={activeEpisode.number}
                        onReviewSubmitted={() => setReviewRefreshKey(prev => prev + 1)}
                      />

                      {/* List */}
                      <EpisodeReviews 
                        showName={selectedShow.name}
                        season={activeEpisode.season}
                        number={activeEpisode.number}
                        refreshKey={reviewRefreshKey}
                      />
                    </div>
                  </motion.section>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {/* ABOUT PAGE */}
          {activePage === 'about' && (
            <motion.div
              key="about-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="max-w-[700px] mx-auto text-left space-y-8"
            >
              <div className="space-y-2">
                <h1 className="text-3xl font-display font-bold text-[#F2F0FA]">About Randomize</h1>
                <p className="text-[#9690B8] text-sm font-sans leading-relaxed">
                  A modern solution to a common 21st-century problem: having too much great content to watch, yet spending 45 minutes browsing without ever picking anything.
                </p>
              </div>

              <div className="space-y-6">
                <div className="panel p-6 bg-white/5 border-white/5 space-y-2">
                  <h3 className="text-gray-950 dark:text-[#F2F0FA] font-bold text-base flex items-center gap-2">
                    <Sparkles className="w-4.5 h-4.5 text-[var(--violet)]" />
                    Why Randomize?
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">
                    Most television fans don't actually struggle to find cool shows. We trust our comfort programs — whether it's <i>The Office</i>, <i>Stranger Things</i>, or local dramas. The actual hurdle is deciding which exact episode to settle for. Randomize answers for you instantly.
                  </p>
                </div>

                <div className="panel p-6 bg-white/5 border-white/5 space-y-2">
                  <h3 className="text-gray-950 dark:text-[#F2F0FA] font-bold text-base flex items-center gap-2">
                    <Tv className="w-4.5 h-4.5 text-[var(--magenta)]" />
                    Reliable Live Data & Smart Autocomplete
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">
                    Show names, metadata, season breakdowns, and posters are gathered directly in real time from public TV catalogs. We have implemented <strong>live autocomplete suggestions</strong> as you type, and <strong>smooth automatic scrolls</strong> directly to the randomizer dials.
                  </p>
                </div>

                <div className="panel p-6 bg-white/5 border-white/5 space-y-2">
                  <h3 className="text-gray-950 dark:text-[#F2F0FA] font-bold text-base flex items-center gap-2">
                    <Plus className="w-4.5 h-4.5 text-[var(--violet)]" />
                    Ultimate Custom Blueprints
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">
                    For long-running series, continuous local dramas, or custom collections with huge episode counts, we've unlocked ultra-high limits. You can now build show blueprints with up to <strong className="text-[#F2F0FA]">1,000 seasons</strong> and <strong className="text-[#F2F0FA]">25,000 episodes</strong>. Perfect for mega series, soaps, and serialised shows!
                  </p>
                </div>

                <div className="panel p-6 bg-white/5 border-white/5 space-y-2">
                  <h3 className="text-gray-950 dark:text-[#F2F0FA] font-bold text-base flex items-center gap-2">
                    <HeartHandshake className="w-4.5 h-4.5 text-[var(--magenta)]" />
                    Customizable Epilogue Discretion
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">
                    Don't want spoilers? We've integrated a custom <strong>Reveal Episode Details</strong> preference setting. Easily toggle details on and off so your randomized episodes stay shrouded in high-suspense mystery until you choose to read them!
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {/* HOW IT WORKS PAGE */}
          {activePage === 'how' && (
            <motion.div
              key="how-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="max-w-[700px] mx-auto text-left space-y-10"
            >
              <div className="space-y-2">
                <h1 className="text-3xl font-display font-bold text-[#F2F0FA]">How it works</h1>
                <p className="text-[#9690B8] text-sm">Follow these simple steps to master and customize your comfort watches.</p>
              </div>

              <div className="space-y-6 relative pl-4 border-l border-white/5 py-2">
                {/* Step 1 */}
                <div className="relative space-y-1 pl-6">
                  <div className="absolute -left-[27px] top-0 w-6 h-6 rounded-full bg-gradient-to-r from-[#7C5CFC] to-[#C66DF2] flex items-center justify-center text-white font-bold font-mono text-xs">
                    1
                  </div>
                  <h3 className="text-[#F2F0FA] font-bold text-base">Type with Live Suggestions & Auto Scroll</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Simply begin typing your favorite shows to see <strong>live autocomplete suggestions</strong> on the fly. Select a suggestion or a Popular Pick to automatically/smoothly scroll straight down to the randomization cylinders.
                  </p>
                </div>

                {/* Step 2 */}
                <div className="relative space-y-1 pl-6 pt-2">
                  <div className="absolute -left-[27px] top-2.5 w-6 h-6 rounded-full bg-gradient-to-r from-[#7C5CFC] to-[#C66DF2] flex items-center justify-center text-white font-bold font-mono text-xs">
                    2
                  </div>
                  <h3 className="text-[#F2F0FA] font-bold text-base">Fine-tune with Filters & Reveal Prefs</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Select exactly which range of seasons to include or apply minimum rating caps. You can also toggle the <strong>Reveal Episode Details</strong> preference to keep descriptions, ratings, and custom poster art completely hidden until you want to view them.
                  </p>
                </div>

                {/* Step 3 */}
                <div className="relative space-y-1 pl-6 pt-2">
                  <div className="absolute -left-[27px] top-2.5 w-6 h-6 rounded-full bg-gradient-to-r from-[#7C5CFC] to-[#C66DF2] flex items-center justify-center text-white font-bold font-mono text-xs">
                    3
                  </div>
                  <h3 className="text-[#F2F0FA] font-bold text-base">Spin and Reveal</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Watch our premium odometer cylinders spin and align to pick out a clean randomized episode.
                  </p>
                </div>

                {/* Step 4 */}
                <div className="relative space-y-1 pl-6 pt-2">
                  <div className="absolute -left-[27px] top-2.5 w-6 h-6 rounded-full bg-gradient-to-r from-[#7C5CFC] to-[#C66DF2] flex items-center justify-center text-white font-bold font-mono text-xs">
                    4
                  </div>
                  <h3 className="text-[#F2F0FA] font-bold text-base">Join the Discussion</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Read fan synopsis notes. Leave a star rating and comment on the episode, or save it to your permanent cloud favorites.
                  </p>
                </div>

                {/* Step 5 */}
                <div className="relative space-y-1 pl-6 pt-2 animate-fadeIn">
                  <div className="absolute -left-[27px] top-2.5 w-6 h-6 rounded-full bg-gradient-to-r from-[#7C5CFC] to-[#C66DF2] flex items-center justify-center text-white font-bold font-mono text-xs">
                    5
                  </div>
                  <h3 className="text-[#F2F0FA] font-bold text-base">Spawn High-Capacity Custom Blueprints</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Can't find a niche show? Build a custom blueprint! We've lifted restrictions to allow massive serialized shows like continuous local dramas/soaps (up to <strong>1,000 seasons</strong> and <strong>25,000 episodes</strong>) and even added server-side generative AI to draft and fact-check inputs automatically!
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {/* FAVORITES PAGE */}
          {activePage === 'favorites' && (
            <motion.div
              key="favorites-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="space-y-6"
            >
              <div className="text-left py-2 border-b border-white/5">
                <h1 className="text-3xl font-display font-bold text-[#F2F0FA]">Your Saved Favorites</h1>
                <p className="text-sm text-[#9690B8]">
                  {currentUser 
                    ? 'Synced permanently under your account.' 
                    : 'Saved offline on your local device. Sign in to sync across devices!'}
                </p>
              </div>

              {favorites.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-5 text-left">
                  {favorites.map((fav) => (
                    <div 
                      key={fav.id} 
                      className="group panel p-3 border-white/5 bg-white/5 relative flex flex-col justify-between h-full"
                    >
                      <div>
                        {/* Remove button */}
                        <button
                          onClick={() => handleRemoveFavoriteByKey(fav.id)}
                          className="absolute top-2.5 right-2.5 w-6 h-6 rounded-full bg-red-500/10 hover:bg-red-500/20 text-red-500 flex items-center justify-center border-0 transition-all cursor-pointer z-10"
                          title="Remove favorite"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>

                        <div className="relative aspect-[16/10] overflow-hidden rounded-lg mb-3 border border-white/5">
                          {fav.image ? (
                            <img 
                              src={fav.image} 
                              alt={fav.title} 
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            />
                          ) : (
                            <div className="w-full h-full bg-[#161616] flex items-center justify-center">
                              <Tv className="w-5 h-5 text-gray-500" />
                            </div>
                          )}
                        </div>

                        <div className="space-y-1">
                          <h4 className="text-sm font-bold text-gray-950 dark:text-[#F2F0FA] truncate leading-snug">
                            {fav.title}
                          </h4>
                          <p className="text-[10px] text-[var(--violet)] font-semibold font-mono truncate">
                            {fav.showName} · S{fav.season} · E{fav.number}
                          </p>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-white/5 mt-3 flex items-center justify-between text-[10px] text-gray-500">
                        <span>Aired {fav.airdate || '—'}</span>
                        <button
                          onClick={() => {
                            setSearchQuery(fav.showName);
                            handleSearchShow(fav.showName);
                            setActivePage('home');
                          }}
                          className="text-[var(--violet)] font-semibold flex items-center gap-0.5 hover:underline bg-transparent border-0 cursor-pointer"
                        >
                          Show details
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="panel p-12 text-center max-w-[480px] mx-auto bg-white/5 border-white/5 space-y-4">
                  <Heart className="w-10 h-10 text-gray-400 dark:text-gray-500 mx-auto stroke-1" />
                  <div className="space-y-1">
                    <h3 className="text-gray-950 dark:text-[#F2F0FA] font-bold text-sm">No favorites saved yet</h3>
                    <p className="text-gray-500 dark:text-gray-400 text-xs">
                      Randomize some shows on home page, click "Save Episode", and find them saved permanently here!
                    </p>
                  </div>
                  <button
                    onClick={() => setActivePage('home')}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[var(--violet)]/10 border border-[var(--violet)]/20 text-[var(--violet)] text-xs font-bold hover:bg-[var(--violet)]/20 cursor-pointer"
                  >
                    Go Randomize
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {/* CUSTOM PROFILES PAGE */}
          {activePage === 'custom' && (
            <motion.div
              key="custom-page"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="space-y-10 text-left"
            >
              <div className="py-2 border-b border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <h1 className="text-3xl font-display font-bold text-[#F2F0FA]">Custom TV Profiles</h1>
                  <p className="text-sm text-[#9690B8]">
                    Can't find a show? Construct a custom blueprint and randomize episodes instantly!
                  </p>
                </div>
                {!currentUser && (
                  <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl px-4 py-2.5 text-xs text-amber-300 max-w-sm flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold leading-normal">Guest Workspace Mode</p>
                      <p className="text-gray-400 mt-0.5">Custom profiles are saved locally on this browser. Sign in to back up and share them with the community!</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Bento Grid layout */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Creation Form Panel (Left) */}
                <div className="md:col-span-5 bg-white/5 border border-white/5 rounded-2xl p-6 space-y-6">
                  <div className="space-y-2">
                    <h2 className="text-lg font-bold text-gray-900 dark:text-[#F2F0FA] flex items-center gap-2">
                      <Plus className="w-5 h-5 text-[var(--magenta)]" />
                      Draft New Profile
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Input basic show details or use our server-side AI to fact-check and auto-populate catalog specifications.
                    </p>
                  </div>

                  <form onSubmit={handleCreateCustomShow} className="space-y-4">
                    {/* Show Title and AI Fact check trigger */}
                    <div className="space-y-2">
                      <label className="block text-[11px] font-mono text-gray-400 uppercase tracking-wider">TV Show Title</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          required
                          value={customShowNameInput}
                          onChange={(e) => setCustomShowNameInput(e.target.value)}
                          placeholder="e.g., Arcane, Firefly..."
                          className="flex-1 bg-[#101010] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-gray-900 dark:text-[#F2F0FA] outline-none focus:border-[var(--violet)]"
                        />
                        <button
                          type="button"
                          onClick={handleFactCheck}
                          disabled={isFactChecking || !customShowNameInput.trim()}
                          className="px-3 rounded-xl bg-[var(--violet)]/10 hover:bg-[var(--violet)]/20 border border-[var(--violet)]/25 text-[var(--violet)] text-xs font-bold transition-all disabled:opacity-40 flex items-center gap-1 shrink-0 cursor-pointer"
                        >
                          {isFactChecking ? (
                            <>
                              <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
                              Checking...
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3.5 h-3.5 text-[var(--magenta)]" />
                              AI Fact-Check
                            </>
                          )}
                        </button>
                      </div>
                      {factCheckError && (
                        <p className="text-[10px] text-red-400 font-mono">⚠️ {factCheckError}</p>
                      )}
                      {factCheckAlert && (
                        <div className={`p-3 rounded-xl text-[11px] border leading-normal ${
                          factCheckAlert.isReal 
                            ? 'bg-green-500/10 border-green-500/25 text-green-300' 
                            : 'bg-indigo-500/10 border-indigo-500/25 text-indigo-300'
                        }`}>
                          <span className="flex items-center gap-1.5 font-bold mb-1">
                            {factCheckAlert.isReal ? <ShieldCheck className="w-4 h-4 text-green-400" /> : <Sparkles className="w-4 h-4 text-indigo-400" />}
                            {factCheckAlert.isReal ? 'Show Fact-Checked' : 'Draft Show Initialized'}
                          </span>
                          {factCheckAlert.message}
                        </div>
                      )}
                    </div>

                    {/* Seasons & Episodes inputs */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="block text-[11px] font-mono text-gray-400 uppercase tracking-wider">Seasons</label>
                        <input
                          type="number"
                          min="1"
                          max="1000"
                          required
                          value={customSeasonsInput === 0 ? '' : customSeasonsInput}
                          onChange={(e) => {
                            const val = parseInt(e.target.value, 10);
                            setCustomSeasonsInput(isNaN(val) ? 0 : Math.max(1, val));
                          }}
                          className="w-full bg-[#101010] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-gray-900 dark:text-[#F2F0FA] outline-none"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="block text-[11px] font-mono text-gray-400 uppercase tracking-wider">Eps Per Season</label>
                        <input
                          type="number"
                          min="1"
                          max="25000"
                          required
                          value={customEpisodesInput === 0 ? '' : customEpisodesInput}
                          onChange={(e) => {
                            const val = parseInt(e.target.value, 10);
                            setCustomEpisodesInput(isNaN(val) ? 0 : Math.max(1, val));
                          }}
                          className="w-full bg-[#101010] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-gray-900 dark:text-[#F2F0FA] outline-none"
                        />
                      </div>
                    </div>

                    {/* Summary overview */}
                    <div className="space-y-1.5">
                      <label className="block text-[11px] font-mono text-gray-400 uppercase tracking-wider">Show Overview (Optional)</label>
                      <textarea
                        rows={2}
                        value={customSummaryInput}
                        onChange={(e) => setCustomSummaryInput(e.target.value)}
                        placeholder="Draft synopsis or outline..."
                        className="w-full bg-[#101010] border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-gray-900 dark:text-[#F2F0FA] outline-none resize-none"
                      />
                    </div>

                    {/* Genre and Year */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="block text-[11px] font-mono text-gray-400 uppercase tracking-wider">Genre</label>
                        <select
                          value={customGenreInput}
                          onChange={(e) => setCustomGenreInput(e.target.value)}
                          className="w-full bg-[#101010] border border-white/10 rounded-xl px-2 py-3 text-sm text-gray-900 dark:text-[#F2F0FA] outline-none"
                        >
                          <option value="Drama">Drama</option>
                          <option value="Comedy">Comedy</option>
                          <option value="Action">Action</option>
                          <option value="Sci-Fi">Sci-Fi</option>
                          <option value="Anime">Anime</option>
                        </select>
                      </div>
                      <div className="space-y-1.5">
                        <label className="block text-[11px] font-mono text-gray-400 uppercase tracking-wider">Premier Year</label>
                        <input
                          type="text"
                          required
                          value={customYearInput}
                          onChange={(e) => setCustomYearInput(e.target.value)}
                          className="w-full bg-[#101010] border border-white/10 rounded-xl px-3.5 py-3 text-sm text-gray-900 dark:text-[#F2F0FA] outline-none"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-gradient-to-r from-[var(--violet)] to-[var(--magenta)] text-white py-3.5 rounded-xl font-bold text-sm hover:brightness-105 active:scale-[0.99] transition-all cursor-pointer shadow-md mt-2 flex items-center justify-center gap-1.5"
                    >
                      <Plus className="w-4.5 h-4.5" />
                      Create & Save Profile
                    </button>
                  </form>
                </div>

                {/* Profiles List Explorer (Right) */}
                <div className="md:col-span-7 space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-bold text-gray-[#F2F0FA] flex items-center gap-2">
                      <Tv className="w-5 h-5 text-[var(--violet)]" />
                      Active Blueprints Pool
                    </h2>
                    <span className="text-[10px] font-mono text-gray-500 bg-white/5 py-1 px-2.5 rounded-full border border-white/5 font-semibold">
                      {customShows.length} Custom Profiles
                    </span>
                  </div>

                  {customShows.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {customShows.map((show) => {
                        const isSelected = selectedCustomShow?.id === show.id;
                        return (
                          <div
                            key={show.id}
                            onClick={() => {
                              setSelectedCustomShow(show);
                              setActiveCustomEpisode(null);
                            }}
                            className={`p-4 border rounded-2xl cursor-pointer text-left transition-all relative flex flex-col justify-between h-full group ${
                              isSelected
                                ? 'bg-gradient-to-br from-[var(--violet)]/10 to-[var(--magenta)]/5 border-[var(--violet)] shadow-md shadow-[var(--violet)]/10'
                                : 'bg-white/5 border-white/5 hover:border-white/10 hover:bg-white/10'
                            }`}
                          >
                            <div>
                              {/* Delete button */}
                              <button
                                onClick={(e) => handleDeleteCustomShow(show.id, e)}
                                className="absolute top-3.5 right-3.5 w-6.5 h-6.5 rounded-full bg-red-500/10 hover:bg-red-500/20 text-red-400 border-0 flex items-center justify-center transition-all cursor-pointer opacity-0 group-hover:opacity-100 z-10"
                                title="Delete Custom Show"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>

                              <p className="text-[10px] font-mono font-bold tracking-wide text-[var(--magenta)] mb-1">
                                {show.genre.toUpperCase()} · {show.premieredYear}
                              </p>
                              <h3 className="font-bold text-base text-gray-900 dark:text-[#F2F0FA] line-clamp-1 mb-1 pr-6 leading-tight">
                                {show.name}
                              </h3>
                              <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-3 leading-relaxed mb-3">
                                {show.summary}
                              </p>
                            </div>

                            <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono font-semibold text-gray-400">
                              <span>{show.seasons} Seasons</span>
                              <span className="text-[var(--violet)]">{show.episodesPerSeason} Ep/Season</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="panel p-12 text-center bg-white/5 border-white/5 space-y-4 rounded-2xl">
                      <Tv className="w-10 h-10 text-gray-500 mx-auto stroke-1" />
                      <div className="space-y-1">
                        <h3 className="text-[#F2F0FA] font-bold text-sm">No custom show profiles yet</h3>
                        <p className="text-gray-500 dark:text-gray-400 text-xs">
                          Input a name on the draft terminal on the left to spawn your custom randomization profiles.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Randomized Custom Result Anchor */}
              {selectedCustomShow && (
                <div id="custom-randomizer-anchor" className="border-t border-white/5 pt-10 space-y-6 max-w-[760px] mx-auto text-center">
                  <div className="space-y-2">
                    <p className="text-[10px] uppercase font-mono tracking-wider text-[var(--violet)] font-bold">READY TO SPIN</p>
                    <h2 className="text-2xl font-display font-bold text-[#F2F0FA] leading-tight">
                      Cylinder Roll: {selectedCustomShow.name}
                    </h2>
                    <p className="text-xs text-gray-400 max-w-md mx-auto">
                      Generate a mathematically bounded randomized sequence: S(1-{selectedCustomShow.seasons}) E(1-{selectedCustomShow.episodesPerSeason}).
                    </p>
                  </div>

                  {/* Trigger button */}
                  <div className="py-4">
                    <button
                      onClick={handleRandomizeCustom}
                      disabled={isSpinning}
                      className="bg-gradient-to-r from-[var(--violet)] to-[var(--magenta)] text-white py-4 px-12 rounded-2xl font-bold text-lg hover:brightness-105 active:scale-[0.98] transition-all cursor-pointer shadow-lg disabled:opacity-40"
                    >
                      {isSpinning ? 'SPINNING CYLINDERS...' : `Randomize ${selectedCustomShow.name}`}
                    </button>
                  </div>

                  {/* Spinning loader */}
                  {isSpinning && (
                    <div className="py-6 space-y-3">
                      <div className="inline-flex gap-2.5 items-center justify-center">
                        <span className="w-3 h-3 rounded-full bg-[#7C5CFC] animate-bounce" />
                        <span className="w-3 h-3 rounded-full bg-[#C66DF2] animate-bounce delay-100" />
                        <span className="w-3 h-3 rounded-full bg-[#7C5CFC] animate-bounce delay-200" />
                      </div>
                      <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Compiling custom arrays...</p>
                    </div>
                  )}

                  {/* Cylinders result ticket */}
                  {!isSpinning && activeCustomEpisode && (
                    <div 
                      id="custom-result-panel" 
                      className="space-y-6 pt-4 animate-scaleUp scroll-mt-24"
                    >
                      {/* Odometer */}
                      <div className="flex justify-center gap-10 bg-[#101010] p-4 border border-white/5 rounded-2xl shadow-xl w-fit mx-auto">
                        <div className="space-y-1">
                          <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-semibold block">SEASON</span>
                          <Odometer value={activeCustomEpisode.season} digits={2} />
                        </div>
                        <div className="space-y-1">
                          <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-semibold block">EPISODE</span>
                          <Odometer value={activeCustomEpisode.number} digits={2} />
                        </div>
                      </div>

                      {/* Info Panel */}
                      {showEpisodeDetails ? (
                        <div className="panel p-6 bg-[#101010] border-white/5 text-left max-w-xl mx-auto flex items-start gap-4">
                          <div className="w-12 h-12 rounded-xl bg-[var(--violet)]/10 flex items-center justify-center shrink-0 border border-[var(--violet)]/10">
                            <Sparkles className="w-6 h-6 text-[var(--violet)]" />
                          </div>
                          <div className="space-y-1.5 flex-1 min-w-0">
                            <span className="text-[9px] font-mono tracking-wider uppercase px-2 py-0.5 rounded bg-[var(--magenta)]/15 text-[var(--magenta)] font-bold">Custom Random Result</span>
                            <h3 className="text-gray-900 dark:text-[#F2F0FA] font-bold text-lg leading-tight truncate mt-1">
                              Season {activeCustomEpisode.season}, Episode {activeCustomEpisode.number}
                            </h3>
                            <p className="text-xs text-gray-400 font-sans leading-relaxed">
                              A completely custom-generated randomization coordinates coordinates. Individual reviews and community score systems are active on standard live networks only. Use the coordinates above to reference your private collections!
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div className="panel p-5 text-center bg-[#101010] border-white/5 space-y-3 max-w-sm mx-auto animate-fadeIn">
                          <div className="w-10 h-10 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 flex items-center justify-center mx-auto">
                            <EyeOff className="w-4.5 h-4.5" />
                          </div>
                          <p className="text-gray-400 text-xs leading-normal">
                            Details for Season {activeCustomEpisode.season} Episode {activeCustomEpisode.number} are hidden to prevent spoilers.
                          </p>
                          <button
                            onClick={() => setShowEpisodeDetails(true)}
                            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[var(--violet)] text-white text-xs font-bold rounded-lg hover:brightness-105 active:scale-[0.98] transition-all cursor-pointer shadow-md"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Reveal Details
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Decorative clean footer */}
      <footer className="w-full text-center py-6 px-6 border-t border-white/5 bg-[#050505] transition-colors">
        <div className="max-w-[1180px] mx-auto text-[10.5px] font-mono text-gray-500 space-y-1 leading-relaxed">
          <p>TV schedules and descriptions provided by TVmaze. Community reviews parsed locally inside Sandbox.</p>
          <p className="text-[10px] text-gray-600">Built with 💜 to assist in solving daily browser decision fatigue. Enjoy.</p>
        </div>
      </footer>

      {/* Auth flows register/login Popup Modal */}
      <AuthModal 
        isOpen={authModalOpen} 
        onClose={() => setAuthModalOpen(false)} 
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <RandomizeApp />
    </ThemeProvider>
  );
}
